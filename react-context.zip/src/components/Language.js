import React, {Component} from "react";



export class LanguageProvider extends Component {
    

    render() {
        const {children} = this.props;
        return children
    }
  
}

